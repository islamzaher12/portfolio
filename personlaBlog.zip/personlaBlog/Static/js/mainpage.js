// تأثير تحميل الصفحة
window.addEventListener("load", () => {
  document.body.style.opacity = "1";
});

// زر الوضع الليلي / النهاري (اختياري مستقبلاً)
